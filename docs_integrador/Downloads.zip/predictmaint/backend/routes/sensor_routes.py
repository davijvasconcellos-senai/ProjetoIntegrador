from flask import Blueprint, jsonify, request
from database.db_connection import get_db_connection
from models.sensor_model import SensorSimulator
from models.anomaly_detection import AnomalyDetector

sensor_bp = Blueprint('sensor', __name__)
simulator = SensorSimulator(machine_id=1)
detector = AnomalyDetector()

@sensor_bp.route('/api/sensor-data', methods=['GET'])
def get_sensor_data():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    cursor.execute('''
        SELECT * FROM sensor_data 
        WHERE machine_id = 1 
        ORDER BY timestamp DESC 
        LIMIT 50
    ''')
    data = cursor.fetchall()
    
    cursor.close()
    conn.close()
    return jsonify(data)

@sensor_bp.route('/api/generate-data', methods=['POST'])
def generate_sensor_data():
    sensor_data = simulator.generate_sensor_data()
    
    # Detectar anomalias
    is_anomaly = detector.detect_anomaly(sensor_data)
    anomaly_details = detector.get_anomaly_details(sensor_data) if is_anomaly else []
    
    # Salvar no banco
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO sensor_data 
        (machine_id, temperature, vibration, pressure, power_consumption)
        VALUES (%s, %s, %s, %s, %s)
    ''', (sensor_data['machine_id'], sensor_data['temperature'], 
          sensor_data['vibration'], sensor_data['pressure'], 
          sensor_data['power_consumption']))
    
    # Registrar anomalias se detectadas
    for anomaly_type, severity in anomaly_details:
        cursor.execute('''
            INSERT INTO anomalies 
            (machine_id, anomaly_type, severity, description)
            VALUES (%s, %s, %s, %s)
        ''', (1, anomaly_type, severity, f'Anomalia detectada: {anomaly_type}'))
    
    conn.commit()
    cursor.close()
    conn.close()
    
    return jsonify({
        'sensor_data': sensor_data,
        'anomalies_detected': anomaly_details,
        'status': 'critical' if is_anomaly else 'normal'
    })