import numpy as np
from sklearn.ensemble import IsolationForest

class AnomalyDetector:
    def __init__(self):
        self.model = IsolationForest(contamination=0.1, random_state=42)
        self.is_fitted = False
    
    def detect_anomaly(self, sensor_data):
        features = np.array([
            sensor_data['temperature'],
            sensor_data['vibration'], 
            sensor_data['pressure'],
            sensor_data['power_consumption']
        ]).reshape(1, -1)
        
        if not self.is_fitted:
            # Para demo, criamos dados de treino fictícios
            train_data = np.random.normal(0, 1, (100, 4))
            self.model.fit(train_data)
            self.is_fitted = True
        
        prediction = self.model.predict(features)
        return prediction[0] == -1
    
    def get_anomaly_details(self, sensor_data):
        anomalies = []
        
        if sensor_data['temperature'] > 65:
            anomalies.append(('high_temperature', 'high'))
        elif sensor_data['temperature'] > 55:
            anomalies.append(('elevated_temperature', 'medium'))
            
        if sensor_data['vibration'] > 6:
            anomalies.append(('high_vibration', 'high'))
        elif sensor_data['vibration'] > 4:
            anomalies.append(('elevated_vibration', 'medium'))
            
        return anomalies