import random
from datetime import datetime

class SensorSimulator:
    def __init__(self, machine_id):
        self.machine_id = machine_id
        self.base_temp = 45.0
        self.base_vibration = 2.5
        self.base_pressure = 100.0
        self.base_power = 15.0
    
    def generate_sensor_data(self):
        # Simula dados normais com variações aleatórias
        temperature = self.base_temp + random.uniform(-5, 8)
        vibration = max(0, self.base_vibration + random.uniform(-1, 3))
        pressure = self.base_pressure + random.uniform(-10, 15)
        power_consumption = self.base_power + random.uniform(-3, 5)
        
        # Simulação ocasional de anomalias (5% de chance)
        if random.random() < 0.05:
            temperature += random.uniform(10, 25)
            vibration += random.uniform(2, 6)
        
        return {
            'machine_id': self.machine_id,
            'temperature': round(temperature, 2),
            'vibration': round(vibration, 2),
            'pressure': round(pressure, 2),
            'power_consumption': round(power_consumption, 2),
            'timestamp': datetime.now()
        }