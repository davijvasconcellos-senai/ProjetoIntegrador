import mysql.connector # pyright: ignore[reportMissingImports]
import os

def get_db_connection():
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='alunolab',
        database='predictmaint'
    )