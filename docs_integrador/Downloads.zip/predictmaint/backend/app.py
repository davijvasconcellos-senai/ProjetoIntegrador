from flask import Flask
from flask_cors import CORS
from routes.sensor_routes import sensor_bp
from routes.dashboard_routes import dashboard_bp

app = Flask(__name__)
CORS(app)

# Registrar blueprints
app.register_blueprint(sensor_bp)
app.register_blueprint(dashboard_bp)

@app.route('/')
def hello():
    return 'PREDICTMAINT API está rodando!'

if __name__ == '__main__':
    app.run(debug=True, port=5000)