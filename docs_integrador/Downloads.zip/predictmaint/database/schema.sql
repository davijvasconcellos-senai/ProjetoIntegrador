CREATE DATABASE IF NOT EXISTS predictmaint;
USE predictmaint;

CREATE TABLE machines (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    model VARCHAR(50),
    status ENUM('operational', 'warning', 'critical') DEFAULT 'operational',
    last_maintenance DATE
);

CREATE TABLE sensor_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    machine_id INT,
    temperature DECIMAL(5,2),
    vibration DECIMAL(5,2),
    pressure DECIMAL(5,2),
    power_consumption DECIMAL(5,2),
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (machine_id) REFERENCES machines(id)
);

CREATE TABLE anomalies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    machine_id INT,
    anomaly_type VARCHAR(50),
    severity ENUM('low', 'medium', 'high'),
    description TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    resolved BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (machine_id) REFERENCES machines(id)
);