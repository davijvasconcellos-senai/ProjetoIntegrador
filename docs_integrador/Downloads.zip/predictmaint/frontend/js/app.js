class PredictMaintApp {
    constructor() {
        this.simulationInterval = null;
        this.chart = null;
        this.init();
    }

    init() {
        this.initializeChart();
        this.bindEvents();
        this.loadHistoricalData();
    }

    bindEvents() {
        document.getElementById('start-simulation').addEventListener('click', () => this.startSimulation());
        document.getElementById('stop-simulation').addEventListener('click', () => this.stopSimulation());
        document.getElementById('reset-data').addEventListener('click', () => this.resetData());
    }

    async startSimulation() {
        this.simulationInterval = setInterval(async () => {
            await this.generateSensorData();
        }, 3000); // Gera dados a cada 3 segundos
    }

    stopSimulation() {
        if (this.simulationInterval) {
            clearInterval(this.simulationInterval);
            this.simulationInterval = null;
        }
    }

    async generateSensorData() {
        try {
            const response = await fetch('http://localhost:5000/api/generate-data', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            const data = await response.json();
            this.updateDashboard(data.sensor_data);
            this.updateAnomalies(data.anomalies_detected);
            this.updateChart(data.sensor_data);
            
        } catch (error) {
            console.error('Erro ao gerar dados:', error);
        }
    }

    updateDashboard(sensorData) {
        document.getElementById('temp-value').textContent = sensorData.temperature;
        document.getElementById('vib-value').textContent = sensorData.vibration;
        document.getElementById('press-value').textContent = sensorData.pressure;
        document.getElementById('power-value').textContent = sensorData.power_consumption;

        // Atualizar status baseado nos valores
        const statusElement = document.getElementById('machine-status');
        if (sensorData.temperature > 65 || sensorData.vibration > 6) {
            statusElement.textContent = 'CRÍTICO';
            statusElement.className = 'status critical';
        } else if (sensorData.temperature > 55 || sensorData.vibration > 4) {
            statusElement.textContent = 'ALERTA';
            statusElement.className = 'status warning';
        } else {
            statusElement.textContent = 'OPERACIONAL';
            statusElement.className = 'status operational';
        }
    }

    updateAnomalies(anomalies) {
        const anomaliesList = document.getElementById('anomalies-list');
        
        if (anomalies.length === 0) {
            anomaliesList.innerHTML = '<div class="anomaly-alert">Nenhuma anomalia detectada</div>';
            return;
        }

        anomaliesList.innerHTML = anomalies.map(anomaly => `
            <div class="anomaly-alert anomaly-${anomaly[1]}">
                <strong>${this.getAnomalyDescription(anomaly[0])}</strong>
                <br>
                <small>Severidade: ${anomaly[1].toUpperCase()}</small>
                <br>
                <small>${new Date().toLocaleTimeString()}</small>
            </div>
        `).join('');
    }

    getAnomalyDescription(type) {
        const descriptions = {
            'high_temperature': 'Temperatura Excessivamente Alta',
            'elevated_temperature': 'Temperatura Elevada',
            'high_vibration': 'Vibração Excessiva',
            'elevated_vibration': 'Vibração Elevada'
        };
        return descriptions[type] || type;
    }

    initializeChart() {
        const ctx = document.getElementById('sensor-chart').getContext('2d');
        this.chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [
                    {
                        label: 'Temperatura (°C)',
                        data: [],
                        borderColor: 'rgb(255, 99, 132)',
                        tension: 0.1
                    },
                    {
                        label: 'Vibração (mm/s)',
                        data: [],
                        borderColor: 'rgb(54, 162, 235)',
                        tension: 0.1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    updateChart(sensorData) {
        const now = new Date().toLocaleTimeString();
        
        this.chart.data.labels.push(now);
        this.chart.data.datasets[0].data.push(sensorData.temperature);
        this.chart.data.datasets[1].data.push(sensorData.vibration);

        // Manter apenas últimos 20 pontos
        if (this.chart.data.labels.length > 20) {
            this.chart.data.labels.shift();
            this.chart.data.datasets[0].data.shift();
            this.chart.data.datasets[1].data.shift();
        }

        this.chart.update();
    }

    async loadHistoricalData() {
        try {
            const response = await fetch('http://localhost:5000/api/sensor-data');
            const data = await response.json();
            // Implementar carregamento de dados históricos no gráfico
        } catch (error) {
            console.error('Erro ao carregar dados históricos:', error);
        }
    }

    async resetData() {
        if (confirm('Tem certeza que deseja resetar todos os dados?')) {
            // Implementar reset do banco de dados
            this.stopSimulation();
            location.reload();
        }
    }
}

// Inicializar a aplicação quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', () => {
    new PredictMaintApp();
});