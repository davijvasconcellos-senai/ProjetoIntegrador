import smtplib
from email.mime.text import MimeText
from email.mime.multipart import MimeMultipart
from models import db, Alerta, User
from threading import Thread
import os

class GerenciadorAlertas:
    def __init__(self):
        self.config_email = {
            'smtp_server': 'smtp.gmail.com',
            'smtp_port': 587,
            'email': 'seu_email@gmail.com',  # Configure com seu email
            'password': 'sua_senha_app'      # Use senha de app
        }
    
    def enviar_alerta_email(self, destinatario, assunto, mensagem):
        """Envia email de alerta em thread separada"""
        thread = Thread(target=self._enviar_email_thread, args=(destinatario, assunto, mensagem))
        thread.start()
    
    def _enviar_email_thread(self, destinatario, assunto, mensagem):
        """Thread para envio de email não-bloqueante"""
        try:
            msg = MimeMultipart()
            msg['From'] = self.config_email['email']
            msg['To'] = destinatario
            msg['Subject'] = assunto
            
            msg.attach(MimeText(mensagem, 'plain'))
            
            server = smtplib.SMTP(self.config_email['smtp_server'], self.config_email['smtp_port'])
            server.starttls()
            server.login(self.config_email['email'], self.config_email['password'])
            server.send_message(msg)
            server.quit()
            
            print(f"Alerta enviado para {destinatario}")
        except Exception as e:
            print(f"Erro ao enviar email: {e}")
    
    def criar_alerta_sistema(self, maquina_id, tipo, severidade, mensagem):
        """Cria alerta no sistema e envia emails se configurado"""
        # Salvar no banco
        alerta = Alerta(
            maquina_id=maquina_id,
            tipo=tipo,
            severidade=severidade,
            mensagem=mensagem
        )
        db.session.add(alerta)
        db.session.commit()
        
        # Enviar emails para usuários que optaram por receber alertas
        usuarios = User.query.filter_by(receber_alertas=True).all()
        for usuario in usuarios:
            assunto = f"ALERTA {severidade.upper()} - Máquina {maquina_id}"
            self.enviar_alerta_email(usuario.email, assunto, mensagem)
    
    def verificar_alertas_automaticos(self, maquina):
        """Verifica condições para alertas automáticos"""
        alertas = []
        
        # Verificar temperatura
        if maquina.temperatura > 35:
            alertas.append({
                'tipo': 'temperatura',
                'severidade': 'alta',
                'mensagem': f'Temperatura crítica ({maquina.temperatura}°C) na máquina {maquina.nome}'
            })
        elif maquina.temperatura > 30:
            alertas.append({
                'tipo': 'temperatura', 
                'severidade': 'media',
                'mensagem': f'Temperatura elevada ({maquina.temperatura}°C) na máquina {maquina.nome}'
            })
        
        # Verificar potência
        if maquina.potencia_laser < 70:
            alertas.append({
                'tipo': 'potencia',
                'severidade': 'alta',
                'mensagem': f'Queda de potência ({maquina.potencia_laser}%) na máquina {maquina.nome}'
            })
        
        # Verificar pressão
        if maquina.pressao_ar < 5:
            alertas.append({
                'tipo': 'pressao',
                'severidade': 'critica',
                'mensagem': f'Pressão de ar muito baixa ({maquina.pressao_ar} bar) na máquina {maquina.nome}'
            })
        
        # Criar alertas no sistema
        for alerta_info in alertas:
            self.criar_alerta_sistema(maquina.id, **alerta_info)

# Instância global
gerenciador_alertas = GerenciadorAlertas()