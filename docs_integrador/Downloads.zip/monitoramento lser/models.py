from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime, timedelta
import json

db = SQLAlchemy()

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    receber_alertas = db.Column(db.Boolean, default=True)

class Maquina(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    modelo = db.Column(db.String(50), default="Laser 6040")
    fabricante = db.Column(db.String(50), default="Duplotech")
    status = db.Column(db.String(20), default="operando")
    localizacao = db.Column(db.String(100))
    
    # Métricas de monitoramento
    temperatura = db.Column(db.Float, default=25.0)
    potencia_laser = db.Column(db.Float, default=85.0)
    horas_operacao = db.Column(db.Float, default=0.0)
    velocidade_corte = db.Column(db.Float, default=100.0)
    pressao_ar = db.Column(db.Float, default(6.0))
    voltagem = db.Column(db.Float, default(220.0))
    
    # Manutenção
    ultima_manutencao = db.Column(db.DateTime)
    proxima_manutencao = db.Column(db.DateTime)
    criticidade = db.Column(db.String(20), default="baixa")  # baixa, media, alta
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class HistoricoManutencao(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    maquina_id = db.Column(db.Integer, db.ForeignKey('maquina.id'), nullable=False)
    tipo_manutencao = db.Column(db.String(50), nullable=False)
    descricao = db.Column(db.Text)
    data_manutencao = db.Column(db.DateTime, default=datetime.utcnow)
    tecnico_responsavel = db.Column(db.String(100))
    custo = db.Column(db.Float)
    duracao_horas = db.Column(db.Float)
    
    maquina = db.relationship('Maquina', backref=db.backref('manutencoes', lazy=True))

class LogMonitoramento(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    maquina_id = db.Column(db.Integer, db.ForeignKey('maquina.id'), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    temperatura = db.Column(db.Float)
    potencia_laser = db.Column(db.Float)
    pressao_ar = db.Column(db.Float)
    voltagem = db.Column(db.Float)
    status = db.Column(db.String(20))
    anomalia_detectada = db.Column(db.Boolean, default=False)
    
    maquina = db.relationship('Maquina', backref=db.backref('logs', lazy=True))

class Alerta(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    maquina_id = db.Column(db.Integer, db.ForeignKey('maquina.id'), nullable=False)
    tipo = db.Column(db.String(50))  # temperatura, potencia, manutencao, falha
    severidade = db.Column(db.String(20))  # baixa, media, alta, critica
    mensagem = db.Column(db.Text)
    lido = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    maquina = db.relationship('Maquina', backref=db.backref('alertas', lazy=True))

class PrevisaoFalha(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    maquina_id = db.Column(db.Integer, db.ForeignKey('maquina.id'), nullable=False)
    probabilidade_falha = db.Column(db.Float)
    tipo_possivel_falha = db.Column(db.String(100))
    recomendacao = db.Column(db.Text)
    data_previsao = db.Column(db.DateTime, default=datetime.utcnow)
    horizonte_dias = db.Column(db.Integer)  # Previsão para quantos dias à frente
    
    maquina = db.relationship('Maquina', backref=db.backref('previsoes', lazy=True))