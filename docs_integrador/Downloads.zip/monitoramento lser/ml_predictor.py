import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from models import db, LogMonitoramento, PrevisaoFalha, Maquina
import joblib
import os

class PreditorFalhas:
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self.model_path = 'ml_model.pkl'
        self.scaler_path = 'ml_scaler.pkl'
        self.carregar_modelo()
    
    def carregar_modelo(self):
        """Carrega o modelo treinado ou cria um novo"""
        if os.path.exists(self.model_path) and os.path.exists(self.scaler_path):
            self.model = joblib.load(self.model_path)
            self.scaler = joblib.load(self.scaler_path)
        else:
            self.model = RandomForestClassifier(n_estimators=100, random_state=42)
            # Treinar com dados iniciais simulados
            self.treinar_modelo_inicial()
    
    def treinar_modelo_inicial(self):
        """Cria dados de treinamento iniciais simulados"""
        # Dados simulados para treinamento inicial
        np.random.seed(42)
        n_samples = 1000
        
        X = np.column_stack([
            np.random.normal(25, 5, n_samples),  # temperatura
            np.random.normal(85, 10, n_samples), # potencia_laser
            np.random.normal(6, 0.5, n_samples), # pressao_ar
            np.random.normal(220, 10, n_samples) # voltagem
        ])
        
        # Regras simples para falhas simuladas
        y = np.zeros(n_samples)
        y[(X[:, 0] > 35) | (X[:, 1] < 70) | (X[:, 2] < 5) | (X[:, 3] < 210)] = 1
        
        X_scaled = self.scaler.fit_transform(X)
        self.model.fit(X_scaled, y)
        
        joblib.dump(self.model, self.model_path)
        joblib.dump(self.scaler, self.scaler_path)
    
    def prever_falha(self, maquina_id):
        """Faz previsão de falha para uma máquina"""
        maquina = Maquina.query.get(maquina_id)
        if not maquina:
            return None
        
        # Coletar dados recentes para previsão
        logs_recentes = LogMonitoramento.query.filter_by(
            maquina_id=maquina_id
        ).order_by(LogMonitoramento.timestamp.desc()).limit(10).all()
        
        if len(logs_recentes) < 5:
            return None
        
        # Calcular médias móveis
        temps = [log.temperatura for log in logs_recentes]
        potencias = [log.potencia_laser for log in logs_recentes]
        pressoes = [log.pressao_ar for log in logs_recentes]
        voltagens = [log.voltagem for log in logs_recentes]
        
        dados_atuais = np.array([[
            np.mean(temps),
            np.mean(potencias),
            np.mean(pressoes),
            np.mean(voltagens)
        ]])
        
        dados_scaled = self.scaler.transform(dados_atuais)
        probabilidade = self.model.predict_proba(dados_scaled)[0][1]
        
        # Determinar tipo de possível falha baseado nos dados
        tipo_falha = self.identificar_tipo_falha(dados_atuais[0])
        recomendacao = self.gerar_recomendacao(dados_atuais[0])
        
        return {
            'probabilidade': round(probabilidade * 100, 2),
            'tipo_falha': tipo_falha,
            'recomendacao': recomendacao
        }
    
    def identificar_tipo_falha(self, dados):
        """Identifica o tipo mais provável de falha"""
        temp, potencia, pressao, voltagem = dados
        
        if temp > 32:
            return "Superaquecimento do laser"
        elif potencia < 75:
            return "Queda de potência do laser"
        elif pressao < 5.5:
            return "Problema no sistema de arrefecimento"
        elif voltagem < 215:
            return "Instabilidade elétrica"
        else:
            return "Desgaste geral dos componentes"
    
    def gerar_recomendacao(self, dados):
        """Gera recomendações baseadas nos dados"""
        temp, potencia, pressao, voltagem = dados
        
        recomendacoes = []
        if temp > 30:
            recomendacoes.append("Verificar sistema de refrigeração")
        if potencia < 80:
            recomendacoes.append("Calibrar fonte de laser")
        if pressao < 5.8:
            recomendacoes.append("Verificar compressor de ar")
        if voltagem < 215:
            recomendacoes.append("Verificar estabilizador de energia")
        
        if not recomendacoes:
            recomendacoes.append("Manutenção preventiva padrão")
        
        return "; ".join(recomendacoes)

# Instância global do preditor
preditor = PreditorFalhas()