from flask import Flask, render_template, jsonify, request, redirect, url_for, send_file
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from models import db, User, Maquina, HistoricoManutencao, LogMonitoramento, Alerta, PrevisaoFalha
from werkzeug.security import generate_password_hash, check_password_hash
from ml_predictor import preditor
from email_alerts import gerenciador_alertas
from report_generator import gerador_relatorios
import random
from datetime import datetime, timedelta
from io import BytesIO

app = Flask(__name__)
app.config['SECRET_KEY'] = 'sua_chave_secreta_super_segura_aqui'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///monitoramento.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# ===== ROTAS DE AUTENTICAÇÃO =====
@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User.query.filter_by(username=request.form['username']).first()
        if user and check_password_hash(user.password, request.form['password']):
            login_user(user)
            return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
    if request.method == 'POST':
        hashed_password = generate_password_hash(request.form['password'])
        new_user = User(
            username=request.form['username'],
            email=request.form['email'],
            password=hashed_password
        )
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('cadastro.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

# ===== DASHBOARD PRINCIPAL =====
@app.route('/dashboard')
@login_required
def dashboard():
    maquinas = Maquina.query.all()
    alertas_nao_lidos = Alerta.query.filter_by(lido=False).count()
    
    # Gerar previsões para cada máquina
    previsoes = {}
    for maquina in maquinas:
        previsao = preditor.prever_falha(maquina.id)
        if previsao:
            previsoes[maquina.id] = previsao
    
    return render_template('dashboard.html', 
                         maquinas=maquinas,
                         alertas_nao_lidos=alertas_nao_lidos,
                         previsoes=previsoes)

# ===== API DADOS TEMPO REAL =====
@app.route('/api/dados-tempo-real/<int:maquina_id>')
@login_required
def dados_tempo_real(maquina_id):
    maquina = Maquina.query.get(maquina_id)
    if not maquina:
        return jsonify({'error': 'Máquina não encontrada'}), 404
    
    # Simular variações nos dados
    maquina.temperatura = round(25 + random.uniform(-2, 8), 1)
    maquina.potencia_laser = round(85 + random.uniform(-10, 5), 1)
    maquina.horas_operacao += 0.1
    maquina.velocidade_corte = round(100 + random.uniform(-10, 5), 1)
    maquina.pressao_ar = round(6 + random.uniform(-1, 0.5), 1)
    maquina.voltagem = round(220 + random.uniform(-5, 5), 1)
    
    # Atualizar criticidade baseado nas métricas
    if maquina.temperatura > 32 or maquina.potencia_laser < 75:
        maquina.criticidade = "alta"
    elif maquina.temperatura > 28 or maquina.potencia_laser < 80:
        maquina.criticidade = "media"
    else:
        maquina.criticidade = "baixa"
    
    # Criar log de monitoramento
    log = LogMonitoramento(
        maquina_id=maquina.id,
        temperatura=maquina.temperatura,
        potencia_laser=maquina.potencia_laser,
        pressao_ar=maquina.pressao_ar,
        voltagem=maquina.voltagem,
        status=maquina.status
    )
    db.session.add(log)
    db.session.commit()
    
    # Verificar alertas automáticos
    gerenciador_alertas.verificar_alertas_automaticos(maquina)
    
    return jsonify({
        'id': maquina.id,
        'nome': maquina.nome,
        'temperatura': maquina.temperatura,
        'potencia_laser': maquina.potencia_laser,
        'horas_operacao': round(maquina.horas_operacao, 1),
        'velocidade_corte': maquina.velocidade_corte,
        'pressao_ar': maquina.pressao_ar,
        'voltagem': maquina.voltagem,
        'status': maquina.status,
        'criticidade': maquina.criticidade,
        'ultima_atualizacao': datetime.now().strftime('%H:%M:%S')
    })

# ===== GERENCIAMENTO DE MÁQUINAS =====
@app.route('/maquinas')
@login_required
def listar_maquinas():
    maquinas = Maquina.query.all()
    return render_template('maquinas.html', maquinas=maquinas)

@app.route('/maquinas/nova', methods=['POST'])
@login_required
def nova_maquina():
    nova_maquina = Maquina(
        nome=request.form['nome'],
        modelo=request.form.get('modelo', 'Laser 6040'),
        fabricante=request.form.get('fabricante', 'Duplotech'),
        localizacao=request.form.get('localizacao', 'Setor de Corte')
    )
    db.session.add(nova_maquina)
    db.session.commit()
    return redirect(url_for('listar_maquinas'))

# ===== MANUTENÇÕES =====
@app.route('/manutencoes')
@login_required
def listar_manutencoes():
    manutencoes = HistoricoManutencao.query.all()
    maquinas = Maquina.query.all()
    return render_template('manutencoes.html', manutencoes=manutencoes, maquinas=maquinas)

@app.route('/manutencoes/nova', methods=['POST'])
@login_required
def nova_manutencao():
    nova_manutencao = HistoricoManutencao(
        maquina_id=request.form['maquina_id'],
        tipo_manutencao=request.form['tipo_manutencao'],
        descricao=request.form['descricao'],
        tecnico_responsavel=request.form['tecnico_responsavel'],
        custo=float(request.form['custo']),
        duracao_horas=float(request.form['duracao_horas'])
    )
    
    # Atualizar data da última manutenção da máquina
    maquina = Maquina.query.get(request.form['maquina_id'])
    maquina.ultima_manutencao = datetime.now()
    maquina.proxima_manutencao = datetime.now() + timedelta(days=30)  # Próxima em 30 dias
    
    db.session.add(nova_manutencao)
    db.session.commit()
    
    return redirect(url_for('listar_manutencoes'))

# ===== ALERTAS =====
@app.route('/alertas')
@login_required
def listar_alertas():
    alertas = Alerta.query.order_by(Alerta.created_at.desc()).all()
    return render_template('alertas.html', alertas=alertas)

@app.route('/alertas/<int:alerta_id>/ler', methods=['POST'])
@login_required
def marcar_alerta_lido(alerta_id):
    alerta = Alerta.query.get(alerta_id)
    if alerta:
        alerta.lido = True
        db.session.commit()
    return redirect(url_for('listar_alertas'))

# ===== PREVISÕES ML =====
@app.route('/previsoes')
@login_required
def previsoes():
    maquinas = Maquina.query.all()
    previsoes_data = {}
    
    for maquina in maquinas:
        previsao = preditor.prever_falha(maquina.id)
        if previsao:
            # Salvar previsão no banco
            nova_previsao = PrevisaoFalha(
                maquina_id=maquina.id,
                probabilidade_falha=previsao['probabilidade'],
                tipo_possivel_falha=previsao['tipo_falha'],
                recomendacao=previsao['recomendacao'],
                horizonte_dias=7
            )
            db.session.add(nova_previsao)
            previsoes_data[maquina.id] = previsao
    
    db.session.commit()
    return render_template('previsoes.html', maquinas=maquinas, previsoes=previsoes_data)

# ===== RELATÓRIOS PDF =====
@app.route('/relatorios/gerar/<int:maquina_id>')
@login_required
def gerar_relatorio(maquina_id):
    # Definir período padrão (últimos 30 dias)
    data_fim = datetime.now()
    data_inicio = data_fim - timedelta(days=30)
    
    pdf_buffer = gerador_relatorios.gerar_relatorio_manutencao(maquina_id, data_inicio, data_fim)
    
    maquina = Maquina.query.get(maquina_id)
    nome_arquivo = f"relatorio_{maquina.nome.replace(' ', '_')}_{datetime.now().strftime('%Y%m%d')}.pdf"
    
    return send_file(pdf_buffer, 
                    as_attachment=True, 
                    download_name=nome_arquivo,
                    mimetype='application/pdf')

# ===== CONFIGURAÇÕES =====
@app.route('/configuracoes', methods=['GET', 'POST'])
@login_required
def configuracoes():
    if request.method == 'POST':
        current_user.receber_alertas = 'receber_alertas' in request.form
        db.session.commit()
        return redirect(url_for('configuracoes'))
    
    return render_template('configuracoes.html')

# ===== INICIALIZAÇÃO =====
def criar_dados_iniciais():
    """Cria dados iniciais para demonstração"""
    with app.app_context():
        if not Maquina.query.first():
            # Criar máquinas de exemplo
            maquinas = [
                Maquina(nome="Laser 6040 - Corte 01", localizacao="Setor A"),
                Maquina(nome="Laser 6040 - Corte 02", localizacao="Setor B"),
                Maquina(nome="Laser 6040 - Marcação", localizacao="Setor C")
            ]
            
            for maquina in maquinas:
                db.session.add(maquina)
            
            db.session.commit()

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        criar_dados_iniciais()
    app.run(debug=True, host='0.0.0.0', port=5000)